

class Cucumber(object):
	pass

class Request(Cucumber):
	"""A cucumber (python object) created for processing a request, typically made by a client."""
	pass
class Response(Cucumber):
	"""A cucumber (python object) created for sending a response, typically made by the server."""
	pass

class Interface_Client(object):
	pass
class Interface_Server(object):
	pass
