from base import Descriptor

class PIDF_LO(Descriptor):
	def __init__(self):
		pass


class Geodetic(PIDF_LO):
	def __init__(self):
		pass


class Civic(PIDF_LO):
	def __init__(self):
		pass
