
class ClientInfo(object):
	def __init__(self, IP):
		self.IP = IP
